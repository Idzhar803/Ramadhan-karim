/*
script gratis not for sale boss
join saluran script free vip?
https://whatsapp.com/channel/0029VaegLveBKfhz5g2mlg1d

developer script : dika id (yt: dikatech_yt)
*/
//~~~~~~~~~~~~~~~~~~~~~~~~~~~//
global.prefa = ['','!','.',',','🐤','🗿']
global.ownername = "DikaTech"
global.botname = "DikaBug"
global.version = "FreeVip"
global.owner = [
  "6285882037263", // ganti nomor owner utama (wajib)
  "6285813224619", // owner 2 kalo ada, gada? kosongin
  "628xxx", // owner 3 kalo ada, gada? kosongin
  "628xxx", // owner 4 kalo ada, gada? kosongin
  "628xxx" // owner 5 kalo ada, gada? kosongin
]
//~~~~~~~~~~~~~~~~~~~~~~~~~~~//
// jangan di ganti/dihapus
global.codelink = "9I00OkhdXrM?si=p7sMUca9NR8ytjNq"
global.UrlSource = "https://chromedino.com/"
global.UrlMedia = "https://files.catbox.moe/pwc31i.jpg"
//~~~~~~~~~~~~~~~~~~~~~~~~~~~//
let fs = require('fs')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})