Hi Kak,

Saya Dika ID, Ingin Mengucapkan Terima Kasih Yang Sebesar-besarnya Atas Dukungan Kalian. Saya Disini Memberikan Script Bot Whatsapp Dengan Fitur Bug Secara Gratis, Jika Masih Ada Kekurangan Dalam Script Mohon Dimaafkan

Beberapa Bagian Script Telah Saya Encrypt Untuk Mencegah Penyalahgunaan, Seperti Recode Atau Rename Tanpa Izin. Script Ini Sepenuhnya Gratis Dan Tidak Diperjualbelikan.

- Source Script
> YouTube : @dikatech_yt
> Saluran Whatsapp : https://whatsapp.com/channel/0029VaegLveBKfhz5g2mlg1d

- Thanks to
> My God (Allah Swt)
> My Inspiration (Muhammad)
> Dika ID (Developer)
> MalzTzy (My Bro)
> CuenkBot (My Icon)
> dan kalian semua yang mendukung saya.